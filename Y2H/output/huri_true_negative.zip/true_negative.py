#!/usr/bin/env python
# coding: utf-8

# In[7]:


import pandas as pd
import numpy as np
import re
import itertools  
df1 = pd.read_csv ("HuRI_pairs.txt", sep=';')  #original file is in Github (HuRI.pmi), performed some modifications to obtain the uniprot codes of the interacting proteins
df1 = df1.drop_duplicates()
df1 = df1.sort_values(by='1')
all_combinations = pd.read_csv ("HuRI_proteins.txt")
all_combinations = all_combinations.drop_duplicates()
all_combinations =np.asarray(all_combinations)
mesh = np.array(np.meshgrid(all_combinations, all_combinations))
combinations = mesh.T.reshape(-1, 2)
combinations = np.asarray(combinations)
df = pd.DataFrame()
df['pair'] = combinations.tolist()
df.to_csv('3.csv')
df = pd.read_csv ("3.csv")
df1["pair"] = "[" + "'" + df1["1"] + "'"+ "," +" "+ "'" + df1["2"] + "'" + "]"
true_negative = df[~df["pair"].isin(df1["pair"])]
true_negative.to_csv('4.csv')
positives = pd.merge(df, df1)
print(positives)
positives.to_csv('5.csv')


# In[10]:


df1


# In[12]:


true_negative


# In[13]:


67760134-8238 


# In[ ]:




