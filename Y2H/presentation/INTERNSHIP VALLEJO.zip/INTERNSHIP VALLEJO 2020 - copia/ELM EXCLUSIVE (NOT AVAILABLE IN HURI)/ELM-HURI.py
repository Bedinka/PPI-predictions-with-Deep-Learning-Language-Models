#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#in this scrip I search which ELM proteins are NOT available in HURI.


# In[1]:


import pandas as pd
df1 = pd.read_csv ("huri.csv", sep=';')
print(df1)
df2 = pd.read_csv ("ELM.txt", sep='\t')
print(df2)


# In[2]:


df1['Domain'] = df1['<hmm acc>'].map(lambda x: str(x)[0:7])   
#to eliminate the decimal points from HMM acc, 
#because the other database only has "integers"
#and I want to find common values
df2 = df2[df2.taxonomyElm == "9606(Homo sapiens)"]


# In[3]:


print(df1)
print(df2)


# In[4]:


df_merge = pd.merge(df1, df2, how='inner')   #to obtain common values between both files
df_merge


# In[5]:


df_merge.to_csv('common_huri_elm.csv') #store common values in a csv file


# In[6]:


df2["pair"] = df2["interactorElm"]+ " " + df2["interactorDomain"]
df2 = df2.drop_duplicates()
df3 = pd.DataFrame(df2["pair"])
print(df3)


# In[7]:


df4 = pd.read_csv ("hur.txt", sep='\t')
df4['PROTEIN 1 (uniprotkb)'] = df4['PROTEIN 1 (uniprotkb)'].map(lambda x: str(x)[0:6])
df4['PROTEIN 2 (uniprotkb)'] = df4['PROTEIN 2 (uniprotkb)'].map(lambda x: str(x)[0:6])
df4["pair"] = df4["PROTEIN 1 (uniprotkb)"]+ " " + df4["PROTEIN 2 (uniprotkb)"]
df4 = df4.drop(columns=["PROTEIN 1 (uniprotkb)", "PROTEIN 2 (uniprotkb)"])
df4 = df4.drop_duplicates()
print(df4)


# In[8]:


df_merge_pairs = pd.merge(df3, df4, how='inner')   #to obtain common values between both files
df_merge_pairs


# In[9]:


df_merge_pairs = df_merge_pairs.to_csv('pairs_elm_in_huri.txt')


# In[17]:


df_not = df3[~df3["pair"].isin(df4["pair"])]
df_not.to_csv("pairs_elm_not_in_huri.txt")
df_not = df_not.pair.str.split(expand=True)
df_not


# In[24]:


frame = [df_not[0], df_not[1]]
proteins = pd.concat(frame)
proteins = proteins.drop_duplicates()
proteins.to_csv("proteins_elm_not_in_huri.txt")
proteins #list of proteins from ELM exclusive pairs


