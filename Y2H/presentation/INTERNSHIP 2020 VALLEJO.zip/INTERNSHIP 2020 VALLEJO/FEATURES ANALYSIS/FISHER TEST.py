#!/usr/bin/env python
# coding: utf-8

# In[2]:


import scipy.stats as stats


# In[2]:


oddsratio, pvalue = stats.fisher_exact([[766, 8139], [998, 7167]])


# In[3]:


pvalue


# In[11]:


oddsratio, pvalue = stats.fisher_exact([[1908, 6997], [955, 7210]])


# In[12]:


pvalue


# In[13]:


oddsratio, pvalue = stats.fisher_exact([[296, 8609], [188, 7977]])


# In[14]:


pvalue


# In[15]:


oddsratio, pvalue = stats.fisher_exact([[411, 8494], [240, 7925]])
pvalue


# In[16]:


oddsratio, pvalue = stats.fisher_exact([[8361, 544], [7762, 403]])
pvalue


# In[17]:


oddsratio, pvalue = stats.fisher_exact([[68, 8837], [69, 8096]])
pvalue


# In[18]:


oddsratio, pvalue = stats.fisher_exact([[2001, 6904], [1146, 7019]])
pvalue


# In[19]:


oddsratio, pvalue = stats.fisher_exact([[2633, 6272], [1686, 6479]])
pvalue


# In[20]:


oddsratio, pvalue = stats.fisher_exact([[99, 8806], [75, 8090]])
pvalue


# In[21]:


oddsratio, pvalue = stats.fisher_exact([[3844, 5061], [3564, 4601]])
pvalue


# In[22]:


oddsratio, pvalue = stats.fisher_exact([[956, 7949], [630, 7535]])
pvalue


# In[23]:


oddsratio, pvalue = stats.fisher_exact([[103, 8802], [112, 8053]])
pvalue


# In[24]:


oddsratio, pvalue = stats.fisher_exact([[630, 8275], [836, 7329]])
pvalue


# In[25]:


oddsratio, pvalue = stats.fisher_exact([[242, 8663], [280, 7885]])
pvalue


# In[26]:


oddsratio, pvalue = stats.fisher_exact([[943, 7962], [618, 7547]])
pvalue


# In[27]:


oddsratio, pvalue = stats.fisher_exact([[2326, 6579], [2248, 5917]])
pvalue


# In[28]:


oddsratio, pvalue = stats.fisher_exact([[774, 8131], [976, 7189]])
pvalue


# In[29]:


oddsratio, pvalue = stats.fisher_exact([[970, 7935], [968, 7197]])
pvalue


# In[30]:


oddsratio, pvalue = stats.fisher_exact([[1890, 7015], [1775, 6390]])
pvalue


# In[31]:


oddsratio, pvalue = stats.fisher_exact([[1185, 7720], [732, 7433]])
pvalue


# In[32]:


oddsratio, pvalue = stats.fisher_exact([[848, 8057], [547, 7618]])
pvalue


# In[33]:


oddsratio, pvalue = stats.fisher_exact([[1087, 7818], [772, 7393]])
pvalue


# In[34]:


oddsratio, pvalue = stats.fisher_exact([[535, 8370], [526, 7639]])
pvalue


# In[35]:


oddsratio, pvalue = stats.fisher_exact([[3, 8902], [1, 8164]])
pvalue


# In[36]:


oddsratio, pvalue = stats.fisher_exact([[3943, 4962], [4172, 3993]])
pvalue


# In[37]:


oddsratio, pvalue = stats.fisher_exact([[341, 8564], [343, 7822]])
pvalue


# In[38]:


oddsratio, pvalue = stats.fisher_exact([[2504, 6401], [1109, 7056]])
pvalue


# In[39]:


oddsratio, pvalue = stats.fisher_exact([[1870, 7035], [890, 7275]])
pvalue


# In[40]:


oddsratio, pvalue = stats.fisher_exact([[718, 8187], [833, 7332]])
pvalue


# In[41]:


oddsratio, pvalue = stats.fisher_exact([[4607, 4298], [4318, 3847]])
pvalue


# In[42]:


oddsratio, pvalue = stats.fisher_exact([[5964, 2941], [4939, 3226]])
pvalue


# In[43]:


oddsratio, pvalue = stats.fisher_exact([[2007, 6898], [1965, 6200]])
pvalue


# In[44]:


oddsratio, pvalue = stats.fisher_exact([[4859, 4046], [4364, 3801]])
pvalue


# In[45]:


oddsratio, pvalue = stats.fisher_exact([[85, 8820], [71, 8094]])
pvalue


# In[46]:


oddsratio, pvalue = stats.fisher_exact([[2625, 6280], [2812, 5353]])
pvalue


# In[47]:


oddsratio, pvalue = stats.fisher_exact([[2168, 6737], [2243, 5922]])
pvalue


# In[48]:


oddsratio , pvalue = stats.fisher_exact([[2482, 6423], [2567, 5598]])
pvalue


# In[49]:


oddsratio , pvalue = stats.fisher_exact([[239, 8666], [212, 7953]])
pvalue


# In[50]:


oddsratio , pvalue = stats.fisher_exact([[1981, 6924], [1711, 6454]])
pvalue


# In[51]:


oddsratio , pvalue = stats.fisher_exact([[97, 8808], [88, 8077]])
pvalue


# In[52]:


oddsratio , pvalue = stats.fisher_exact([[72, 8833], [58, 8107]])
pvalue


# In[53]:


oddsratio , pvalue = stats.fisher_exact([[779, 8126], [674, 7491]])
pvalue


# In[54]:


oddsratio , pvalue = stats.fisher_exact([[3, 8902], [1, 8164]])
pvalue


# In[55]:


oddsratio , pvalue = stats.fisher_exact([[464, 8441], [293, 7872]])
pvalue


# In[1]:


#ara elm exclusive vs huri


# In[3]:


oddsratio , pvalue = stats.fisher_exact([[91, 470], [998, 7167]])
pvalue


# In[4]:


oddsratio , pvalue = stats.fisher_exact([[68, 493], [955, 7210]])
pvalue


# In[5]:


oddsratio , pvalue = stats.fisher_exact([[4, 557], [188, 7977]])
pvalue


# In[6]:


oddsratio , pvalue = stats.fisher_exact([[12, 549], [240, 7925]])
pvalue


# In[7]:


oddsratio , pvalue = stats.fisher_exact([[2, 559], [69, 8096]])
pvalue


# In[9]:


oddsratio , pvalue = stats.fisher_exact([[82, 479], [1146, 7019]])
pvalue


# In[10]:


oddsratio , pvalue = stats.fisher_exact([[88, 473], [1686, 6479]])
pvalue


# In[11]:


oddsratio , pvalue = stats.fisher_exact([[7, 554], [75, 8090]])
pvalue


# In[12]:


oddsratio , pvalue = stats.fisher_exact([[399, 162], [3564, 4601]])
pvalue


# In[13]:


oddsratio , pvalue = stats.fisher_exact([[86, 475], [630, 7535]])
pvalue


# In[14]:


oddsratio , pvalue = stats.fisher_exact([[13, 548], [112, 8053]])
pvalue


# In[15]:


oddsratio , pvalue = stats.fisher_exact([[67, 494], [836, 7329]])
pvalue


# In[16]:


oddsratio , pvalue = stats.fisher_exact([[38, 523], [280, 7885]])
pvalue


# In[17]:


oddsratio , pvalue = stats.fisher_exact([[115, 446], [618, 7547]])
pvalue


# In[18]:


oddsratio , pvalue = stats.fisher_exact([[311, 250], [2248, 5917]])
pvalue


# In[19]:


oddsratio , pvalue = stats.fisher_exact([[84, 477], [976, 7189]])
pvalue


# In[20]:


oddsratio , pvalue = stats.fisher_exact([[183, 378], [968, 7197]])
pvalue


# In[21]:


oddsratio , pvalue = stats.fisher_exact([[237, 324], [1775, 6390]])
pvalue


# In[22]:


oddsratio , pvalue = stats.fisher_exact([[124, 437], [732, 7433]])
pvalue


# In[23]:


oddsratio , pvalue = stats.fisher_exact([[58, 503], [547, 7618]])
pvalue


# In[24]:


oddsratio , pvalue = stats.fisher_exact([[130, 431], [772, 7393]])
pvalue


# In[25]:


oddsratio , pvalue = stats.fisher_exact([[80, 481], [526, 7639]])
pvalue


# In[26]:


oddsratio , pvalue = stats.fisher_exact([[1, 560], [1, 8164]])
pvalue


# In[27]:


oddsratio , pvalue = stats.fisher_exact([[495, 66], [4172, 3993]])
pvalue


# In[28]:


oddsratio , pvalue = stats.fisher_exact([[17, 544], [343, 7822]])
pvalue


# In[29]:


oddsratio , pvalue = stats.fisher_exact([[86, 475], [1109, 7056]])
pvalue


# In[30]:


oddsratio , pvalue = stats.fisher_exact([[72, 489], [890, 7275]])
pvalue


# In[31]:


oddsratio , pvalue = stats.fisher_exact([[125, 436], [833, 7332]])
pvalue


# In[32]:


oddsratio , pvalue = stats.fisher_exact([[472, 89], [4318, 3847]])
pvalue


# In[33]:


oddsratio , pvalue = stats.fisher_exact([[442, 119], [4939, 3226]])
pvalue


# In[34]:


oddsratio , pvalue = stats.fisher_exact([[314, 247], [1965, 6200]])
pvalue


# In[35]:


oddsratio , pvalue = stats.fisher_exact([[418, 143], [4364, 3801]])
pvalue


# In[38]:


oddsratio , pvalue = stats.fisher_exact([[331, 230], [2243, 5922]])
pvalue


# In[37]:


oddsratio , pvalue = stats.fisher_exact([[383, 178], [2812, 5353]])
pvalue


# In[39]:


oddsratio , pvalue = stats.fisher_exact([[358, 203], [2567, 5598]])
pvalue


# In[40]:


oddsratio , pvalue = stats.fisher_exact([[15, 546], [212, 7953]])
pvalue


# In[41]:


oddsratio , pvalue = stats.fisher_exact([[176, 385], [1711, 6454]])
pvalue


# In[42]:


oddsratio , pvalue = stats.fisher_exact([[9, 552], [88, 8077]])
pvalue


# In[43]:


oddsratio , pvalue = stats.fisher_exact([[6, 555], [58, 8107]])
pvalue


# In[44]:


oddsratio , pvalue = stats.fisher_exact([[70, 491], [674, 7491]])
pvalue


# In[45]:


oddsratio , pvalue = stats.fisher_exact([[1, 560], [1, 8164]])
pvalue


# In[46]:


oddsratio , pvalue = stats.fisher_exact([[44, 517], [293, 7872]])
pvalue


# In[ ]:




